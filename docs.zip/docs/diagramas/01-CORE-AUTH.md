# Diagrama Core + Auth (Actualizado 2026-05-20)

```mermaid
classDiagram
    direction LR

    class App {
      +templateUrl: app.html
    }

    class AppRoutes {
      +routes: Routes
    }

    class AuthGuard {
      +canActivate(route, state) boolean
    }

    class RoleGuard {
      +roleGuard(rolesPermitidos: string[]) CanActivateFn
    }

    class AuthInterceptor {
      +intercept(req, next) Observable~HttpEvent~
    }

    class Constantes {
      +API_BASE_URL: string
      +ESTADOS_COTIZACION: readonly
      +ROLES_USUARIO: readonly
    }

    class Usuario {
      +id: number
      +nombre: string
      +email: string
      +telefono: string
      +empresa: string
      +cargo: string
      +codigoPostal: string
      +rol: string
    }

    class LoginRequest {
      +email: string
      +password: string
    }

    class LoginResponse {
      +token: string
      +usuario: Usuario
    }

    class ActualizarPerfilDto {
      +nombre: string
      +correo: string
      +telefono: string
      +empresa: string
      +cargo: string
      +codigoPostal: string
    }

    class AuthServicio {
      +login(credenciales: LoginRequest) Observable~LoginResponse~
      +registro(datos: any) Observable~LoginResponse~
      +actualizarPerfil(dto: ActualizarPerfilDto) Observable~Usuario~
      +cambiarPassword(actual: string, nueva: string) Observable~MensajeDto~
      +solicitarRecuperacion(email: string) Observable~MensajeDto~
      +resetearPassword(email: string, codigo: string, nuevaPassword: string) Observable~MensajeDto~
      +logout() void
      +obtenerToken() string
      +estáAutenticado() boolean
      +obtenerUsuarioActual() Usuario
      +tieneRol(rol: string) boolean
    }

    class MensajeDto {
      +mensaje: string
    }

    class LoginComponente {
      +iniciarSesion() void
    }

    class PerfilComponente {
      +guardar() void
      +cambiarPassword() void
    }

    class RecuperarPasswordComponente {
      +solicitarCodigo() void
      +resetearPassword() void
    }

    class NavbarComponente {
      +esAdmin() boolean
      +cerrarSesion() void
    }

    class FooterComponente

    App --> AppRoutes : usa
    App --> NavbarComponente : renderiza
    App --> FooterComponente : renderiza
    AuthGuard ..> AuthServicio : valida sesion
    RoleGuard ..> AuthServicio : valida rol
    AuthInterceptor ..> AuthServicio : inyecta token
    LoginComponente --> AuthServicio : autentica
    PerfilComponente --> AuthServicio : actualiza perfil
    RecuperarPasswordComponente --> AuthServicio : recupera contrasena
    NavbarComponente --> AuthServicio : sesion actual
    AuthServicio o-- Usuario
    AuthServicio ..> LoginRequest
    AuthServicio ..> LoginResponse
    AuthServicio ..> ActualizarPerfilDto
    LoginResponse o-- Usuario
```

**Notas:**
- `AuthInterceptor` inyecta `Authorization: Bearer <token>` en cada petición y hace logout automático en respuestas 401.
- `authGuard` protege rutas que requieren sesión activa; `roleGuard` restringe por rol (`admin`).
- `RecuperarPasswordComponente` tiene dos pasos: (1) solicitar código por correo, (2) ingresar código + nueva contraseña.
