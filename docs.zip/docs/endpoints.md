# Endpoints de la API — CyacoERP

Base URL en desarrollo: `http://localhost:3000/api`

Leyenda:
- 🔓 Público (sin autenticación)
- 🔐 Requiere JWT (cualquier usuario autenticado)
- 🛡️ Requiere JWT + rol `admin`

---

## Auth — `/api/auth`

| Método | URL                        | Acceso | Descripción                              |
|--------|----------------------------|--------|------------------------------------------|
| POST   | `/api/auth/registro`       | 🔓     | Crea cuenta de cliente nueva             |
| POST   | `/api/auth/login`          | 🔓     | Inicia sesión, devuelve JWT              |
| GET    | `/api/auth/perfil`         | 🔐     | Devuelve datos del usuario autenticado   |

**Ejemplo login:**
```http
POST http://localhost:3000/api/auth/login
Content-Type: application/json

{
  "email": "admin@cyaco.local",
  "password": "Admin12345"
}
```

---

## Usuarios — `/api/usuarios`

> Todos requieren JWT + rol `admin`

| Método | URL                                      | Acceso | Descripción                            |
|--------|------------------------------------------|--------|----------------------------------------|
| GET    | `/api/usuarios`                          | 🛡️     | Lista todos los usuarios               |
| GET    | `/api/usuarios/:id`                      | 🛡️     | Obtiene un usuario por ID              |
| POST   | `/api/usuarios`                          | 🛡️     | Crea un usuario nuevo                  |
| PUT    | `/api/usuarios/:id`                      | 🛡️     | Actualiza datos del usuario            |
| DELETE | `/api/usuarios/:id`                      | 🛡️     | Desactiva (soft delete) un usuario     |
| POST   | `/api/usuarios/:id/cambiar-password`     | 🛡️     | Cambia la contraseña de un usuario     |

---

## Clientes — `/api/clientes`

> Todos requieren JWT + rol `admin`

| Método | URL                    | Acceso | Descripción                           |
|--------|------------------------|--------|---------------------------------------|
| POST   | `/api/clientes`        | 🛡️     | Crea un cliente nuevo                 |
| GET    | `/api/clientes`        | 🛡️     | Lista clientes (soporta filtros query)|
| GET    | `/api/clientes/:id`    | 🛡️     | Obtiene un cliente por ID             |
| PATCH  | `/api/clientes/:id`    | 🛡️     | Actualiza datos del cliente           |
| DELETE | `/api/clientes/:id`    | 🛡️     | Desactiva (soft delete) un cliente    |

**Filtros disponibles en GET `/api/clientes`:**
```
?busqueda=texto       — filtra por nombre o empresa
?activo=true|false    — filtra por estado
```

---

## Productos — `/api/productos`

| Método | URL                            | Acceso | Descripción                                |
|--------|--------------------------------|--------|--------------------------------------------|
| GET    | `/api/productos`               | 🔓     | Lista todos los productos activos           |
| GET    | `/api/productos/:id`           | 🔓     | Obtiene un producto por ID                  |
| POST   | `/api/productos`               | 🛡️     | Crea un producto nuevo                      |
| PUT    | `/api/productos/:id`           | 🛡️     | Actualiza un producto                       |
| DELETE | `/api/productos/:id`           | 🛡️     | Elimina un producto                         |
| POST   | `/api/productos/:id/documento` | 🛡️     | Sube ficha técnica PDF (multipart/form-data)|

**Subida de documento:**
```http
POST http://localhost:3000/api/productos/1/documento
Authorization: Bearer <token>
Content-Type: multipart/form-data

archivo: [archivo.pdf]  (máx 10 MB)
```

---

## Categorías — `/api/categorias`

| Método | URL                      | Acceso | Descripción                     |
|--------|--------------------------|--------|---------------------------------|
| GET    | `/api/categorias`        | 🔓     | Lista todas las categorías      |
| GET    | `/api/categorias/:id`    | 🔓     | Obtiene una categoría por ID    |
| POST   | `/api/categorias`        | 🛡️     | Crea una categoría nueva        |
| PUT    | `/api/categorias/:id`    | 🛡️     | Actualiza una categoría         |
| DELETE | `/api/categorias/:id`    | 🛡️     | Elimina una categoría           |

---

## Cotizaciones — `/api/cotizaciones`

| Método | URL                            | Acceso | Descripción                                          |
|--------|--------------------------------|--------|------------------------------------------------------|
| POST   | `/api/cotizaciones`            | 🔐     | Crea una cotización (con items de productos)          |
| GET    | `/api/cotizaciones/mis`        | 🔐     | Lista cotizaciones del usuario autenticado            |
| GET    | `/api/cotizaciones`            | 🛡️     | Lista todas las cotizaciones (solo admin)             |
| GET    | `/api/cotizaciones/:id`        | 🔐     | Obtiene una cotización por ID                        |
| PATCH  | `/api/cotizaciones/:id/estado` | 🔐     | Cambia el estado de una cotización                   |

**Estados válidos de cotización:** `borrador` | `enviada` | `aceptada` | `rechazada` | `cancelada`

---

## Proyectos — `/api/proyectos`

| Método | URL                                                      | Acceso | Descripción                              |
|--------|----------------------------------------------------------|--------|------------------------------------------|
| GET    | `/api/proyectos`                                         | 🔐     | Lista proyectos (admin: todos, cliente: los suyos)|
| GET    | `/api/proyectos/filtro/activos`                          | 🔐     | Lista proyectos activos no finalizados   |
| GET    | `/api/proyectos/:id`                                     | 🔐     | Obtiene detalle de un proyecto           |
| POST   | `/api/proyectos`                                         | 🔐     | Crea un proyecto nuevo                   |
| PUT    | `/api/proyectos/:id`                                     | 🔐     | Actualiza un proyecto                    |
| PATCH  | `/api/proyectos/:id/estado`                              | 🔐     | Cambia el estado del proyecto            |
| DELETE | `/api/proyectos/:id`                                     | 🔐     | Desactiva (soft delete) un proyecto      |
| GET    | `/api/proyectos/:id/tareas`                              | 🔐     | Lista tareas del proyecto                |
| POST   | `/api/proyectos/:id/tareas`                              | 🔐     | Agrega una tarea al proyecto             |
| PATCH  | `/api/proyectos/:id/tareas/:tareaId`                     | 🔐     | Actualiza datos de una tarea             |
| PATCH  | `/api/proyectos/:id/tareas/:tareaId/estado/:estado`      | 🔐     | Mueve una tarea a otro estado            |
| GET    | `/api/proyectos/:id/bitacora`                            | 🔐     | Lista entradas de bitácora del proyecto  |
| POST   | `/api/proyectos/:id/bitacora`                            | 🔐     | Agrega una entrada a la bitácora         |

**Estados válidos de proyecto:** `planificacion` | `en_progreso` | `pausado` | `finalizado` | `cancelado`

**Estados válidos de tarea:** `pendiente` | `en_progreso` | `completada` | `bloqueada`

---

## Reportes — `/api/reportes`

> Todos requieren JWT + rol `admin`

| Método | URL                                    | Acceso | Descripción                                      |
|--------|----------------------------------------|--------|--------------------------------------------------|
| GET    | `/api/reportes/dashboard/ventas`       | 🛡️     | KPIs de ventas y cotizaciones                    |
| GET    | `/api/reportes/dashboard/clientes`     | 🛡️     | KPIs de clientes activos y nuevos                |
| GET    | `/api/reportes/dashboard/proyectos`    | 🛡️     | KPIs de proyectos y próximos hitos               |
| GET    | `/api/reportes`                        | 🛡️     | Lista reportes generados en memoria              |
| POST   | `/api/reportes/generar`                | 🛡️     | Genera y guarda un reporte nuevo                 |
| GET    | `/api/reportes/:id/exportar/:formato`  | 🛡️     | Descarga reporte en PDF, Excel o CSV             |

**Ejemplo generar reporte:**
```http
POST http://localhost:3000/api/reportes/generar
Authorization: Bearer <token>
Content-Type: application/json

{
  "tipo": "ventas",
  "formato": "pdf"
}
```

**Formatos de exportación:** `pdf` | `excel` | `csv`

---

## Archivos estáticos

| URL                           | Descripción                        |
|-------------------------------|------------------------------------|
| `/uploads/documentos/:archivo`| Fichas técnicas PDF de productos   |

---

## Resumen de conteo

| Módulo       | Endpoints |
|--------------|-----------|
| Auth         | 3         |
| Usuarios     | 6         |
| Clientes     | 5         |
| Productos    | 6         |
| Categorías   | 5         |
| Cotizaciones | 5         |
| Proyectos    | 12        |
| Reportes     | 6         |
| **Total**    | **48**    |
