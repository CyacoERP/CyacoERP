# Guia Completa del Flujo PayPal (Flutter + Backend + PayPal API)

Este documento describe el flujo completo para que puedas explicarlo paso a paso, desde la accion del usuario en Flutter hasta las llamadas a PayPal y actualizacion de BD en backend.

## 1) Vista General End-to-End

1. Usuario entra a checkout y elige PayPal en Flutter.
2. Flutter crea pedido local (`/orders`) y luego solicita crear orden PayPal (`/transacciones/paypal/create-order`).
3. Backend crea transaccion local en `Pendiente` y llama a PayPal `v2/checkout/orders`.
4. Flutter abre navegador con URL de aprobacion PayPal.
5. Usuario aprueba en PayPal y vuelve por deep link `resello://paypal-return`.
6. Flutter detecta regreso (lifecycle), llama a `capture` en backend (`/transacciones/paypal/capture`).
7. Backend valida estado de orden, captura en PayPal `v2/checkout/orders/{id}/capture`.
8. Backend marca transaccion `Completado`, pedido `Pagado`, crea escrows por vendedor (10% comision plataforma, 90% vendedor).
9. Cuando comprador confirma entrega por QR, backend libera escrows y dispara payout PayPal al vendedor (`v1/payments/payouts`) si tiene `email_paypal`.

## 2) Flutter: Desde la accion del usuario

### 2.1 Checkout inicia pago

- Metodo principal de pago:
  - [_pay en checkout_screen.dart](../../resell_o/lib/screens/buyer/checkout_screen.dart#L472)
- Crea primero pedido local:
  - [OrderService.createOrder llamado en checkout](../../resell_o/lib/screens/buyer/checkout_screen.dart#L491)
  - [OrderService.createOrder implementacion](../../resell_o/lib/services/order_service.dart#L68)
  - [POST /orders](../../resell_o/lib/services/order_service.dart#L70)
- Si metodo es PayPal, redirige al flujo PayPal:
  - [if paypal -> _handlePayPalPayment](../../resell_o/lib/screens/buyer/checkout_screen.dart#L501)

### 2.2 Flujo PayPal en Flutter (paso a paso)

- Funcion orquestadora:
  - [_handlePayPalPayment](../../resell_o/lib/screens/buyer/checkout_screen.dart#L522)
- Paso A: Crear orden PayPal en backend:
  - [createOrder Flutter](../../resell_o/lib/screens/buyer/checkout_screen.dart#L533)
  - Deep links enviados al backend:
    - [returnUrl resello://paypal-return](../../resell_o/lib/screens/buyer/checkout_screen.dart#L536)
    - [cancelUrl resello://paypal-cancel](../../resell_o/lib/screens/buyer/checkout_screen.dart#L537)
- Paso B: Abrir checkout PayPal en navegador:
  - [launchPayPalCheckout llamado](../../resell_o/lib/screens/buyer/checkout_screen.dart#L564)
  - [launchPayPalCheckout implementacion](../../resell_o/lib/services/paypal_service.dart#L100)
- Paso C: Esperar regreso desde PayPal:
  - [_waitForPayPalReturn](../../resell_o/lib/screens/buyer/checkout_screen.dart#L628)
  - El regreso se detecta por lifecycle:
    - [didChangeAppLifecycleState](../../resell_o/lib/screens/buyer/checkout_screen.dart#L130)
- Paso D: Capturar con reintentos:
  - [_capturePayPalWithRetry](../../resell_o/lib/screens/buyer/checkout_screen.dart#L642)
  - [captureOrder Flutter](../../resell_o/lib/services/paypal_service.dart#L140)
- Paso E: Navegar a success:
  - [push paymentSuccess](../../resell_o/lib/screens/buyer/checkout_screen.dart#L613)

## 3) Flutter Router y Deep Links

- Ruta de payment success:
  - [AppRouter paymentSuccess](../../resell_o/lib/routes/app_router.dart#L30)
- Manejo de deep link PayPal para evitar pantalla de error:
  - [comentario deep link PayPal](../../resell_o/lib/routes/app_router.dart#L109)
  - [deteccion token y PayerID](../../resell_o/lib/routes/app_router.dart#L113)
  - [fallback Ruta no encontrada](../../resell_o/lib/routes/app_router.dart#L125)

### Android intent filters

- Soporte deep links en Android:
  - [paypal-return y paypal-cancel en AndroidManifest](../../resell_o/android/app/src/main/AndroidManifest.xml#L36)

## 4) Flutter API Client e Interceptor (JWT)

- Interceptor registrado en Dio:
  - [_dio.interceptors.addAll](../../resell_o/lib/services/api_client.dart#L47)
- Interceptor auth:
  - [class _AuthInterceptor](../../resell_o/lib/services/api_client.dart#L212)
- Inyeccion Bearer token en cada request protegida:
  - [onRequest](../../resell_o/lib/services/api_client.dart#L219)
  - [Authorization header](../../resell_o/lib/services/api_client.dart#L235)
- Retry tras 401 + refresh token:
  - [onError](../../resell_o/lib/services/api_client.dart#L242)
  - [refresh endpoint /auth/refresh](../../resell_o/lib/services/api_client.dart#L119)

## 5) Backend: Endpoints de PayPal

Archivo principal:
- [transacciones.py](../app/api/v1/endpoints/transacciones.py)

### 5.1 Create Order (backend)

- Endpoint:
  - [POST /paypal/create-order](../app/api/v1/endpoints/transacciones.py#L177)
  - [paypal_create_order](../app/api/v1/endpoints/transacciones.py#L184)
- Flujo interno:
  - Crea transaccion local `Pendiente` via servicio.
  - Llama a PayPal service `create_order`.
  - Guarda metadata (`paypal_order_id`, `approve_url`, etc.) y responde al cliente.

### 5.2 Capture (backend)

- Endpoint:
  - [POST /paypal/capture](../app/api/v1/endpoints/transacciones.py#L276)
  - [paypal_capture_order](../app/api/v1/endpoints/transacciones.py#L282)
- Flujo interno:
  - Valida que transaccion exista y corresponda con `paypal_order_id`.
  - Verifica estado de orden (`APPROVED`) con polling corto antes de capturar.
  - Captura en PayPal.
  - Si `COMPLETED`, llama `completar_transaccion` (crea escrows, marca pedido `Pagado`).

### 5.3 Webhook (idempotente)

- Endpoint:
  - [POST /paypal/webhook](../app/api/v1/endpoints/transacciones.py#L415)
  - [paypal_webhook](../app/api/v1/endpoints/transacciones.py#L421)
- Valida firma con PayPal y procesa eventos:
  - `PAYMENT.CAPTURE.COMPLETED`
  - `PAYMENT.CAPTURE.REFUNDED`
  - `CUSTOMER.DISPUTE.CREATED`

## 6) Backend: Servicio de integracion PayPal

Archivo:
- [paypal_service.py](../app/services/paypal_service.py)

- Obtiene token OAuth:
  - [_get_access_token](../app/services/paypal_service.py#L56)
- Crea orden PayPal:
  - [create_order](../app/services/paypal_service.py#L91)
  - Llama a `POST /v2/checkout/orders`.
- Captura orden:
  - [capture_order](../app/services/paypal_service.py#L159)
  - Llama a `POST /v2/checkout/orders/{id}/capture`.
- Consulta estado de orden:
  - [get_order_status](../app/services/paypal_service.py#L199)
- Verifica firma webhook:
  - [verify_webhook_signature](../app/services/paypal_service.py#L230)
- Nuevo payout a vendedor:
  - [send_payout](../app/services/paypal_service.py#L287)
  - Llama a `POST /v1/payments/payouts`.

## 7) Backend: Transaccion, escrows, comision y payout

Archivo:
- [transaccion_service.py](../app/services/transaccion_service.py)

### 7.1 Crear transaccion local

- [crear_transaccion](../app/services/transaccion_service.py#L16)
- Estado inicial: `Pendiente`.

### 7.2 Completar transaccion al capturar

- [completar_transaccion](../app/services/transaccion_service.py#L65)
- Acciones:
  - Marca transaccion `Completado`.
  - Marca pedido `Pagado`.
  - Agrupa por vendedor y crea escrows.
  - Aplica comision plataforma (default 10%):
    - [comision_plataforma_porcentaje](../app/config/settings.py#L172)
  - Estados iniciales de escrow: `Retenido`.

### 7.3 Liberar escrow y pagar vendedor

- [liberar_escrow](../app/services/transaccion_service.py#L134)
- Si vendedor tiene `email_paypal`, dispara `send_payout` y marca transferencia `Completado`.
- Si NO tiene email, marca `Pendiente_email`:
  - [Pendiente_email](../app/services/transaccion_service.py#L194)

### 7.4 Liberacion automatica por pedido

- [liberar_escrows_por_pedido](../app/services/transaccion_service.py#L201)
- Libera todos los escrows `Retenido` activos del pedido.

## 8) Backend: Trigger por QR de entrega (auto-liberacion)

Archivo:
- [qr_service.py](../app/services/qr_service.py)

- Al escanear `Recogida_comprador` y estado valido:
  - [tipo Recogida_comprador](../app/services/qr_service.py#L205)
  - Cambia pedido a `Entregado`:
    - [pedido = Entregado](../app/services/qr_service.py#L209)
  - Dispara liberacion automatica de escrows:
    - [liberar_escrows_por_pedido](../app/services/qr_service.py#L213)

## 9) Registro del email PayPal del vendedor

### 9.1 Persistencia DB

- Nueva migracion:
  - [0012_add_paypal_email_to_vendedor.py](../alembic/versions/0012_add_paypal_email_to_vendedor.py#L12)
  - [ADD COLUMN email_paypal](../alembic/versions/0012_add_paypal_email_to_vendedor.py#L21)
- Modelo:
  - [Vendedor.email_paypal](../app/models/user.py#L120)

### 9.2 Schemas

- [VendedorPayPalEmailUpdate](../app/schemas/transaccion.py#L71)
- [VendedorPayPalEmailRespuesta](../app/schemas/transaccion.py#L77)

### 9.3 Endpoints

- Obtener email:
  - [GET /vendedor/paypal-email](../app/api/v1/endpoints/transacciones.py#L565)
  - [obtener_email_paypal_vendedor](../app/api/v1/endpoints/transacciones.py#L569)
- Actualizar email:
  - [PUT /vendedor/paypal-email](../app/api/v1/endpoints/transacciones.py#L590)
  - [actualizar_email_paypal_vendedor](../app/api/v1/endpoints/transacciones.py#L594)

### 9.4 Pantalla Flutter de vendedor

- Pantalla nueva:
  - [seller_payment_settings_screen.dart](../../resell_o/lib/screens/seller/seller_payment_settings_screen.dart)
- Carga email actual (GET):
  - [_loadCurrentEmail](../../resell_o/lib/screens/seller/seller_payment_settings_screen.dart#L34)
  - [GET endpoint llamado](../../resell_o/lib/screens/seller/seller_payment_settings_screen.dart#L41)
- Guarda email (PUT):
  - [_saveEmail](../../resell_o/lib/screens/seller/seller_payment_settings_screen.dart#L71)
  - [PUT endpoint llamado](../../resell_o/lib/screens/seller/seller_payment_settings_screen.dart#L80)
- Acceso desde Hub vendedor:
  - [Boton Cuenta de cobro](../../resell_o/lib/screens/seller/seller_hub_screen.dart#L238)
  - [Navega a sellerPaymentSettings](../../resell_o/lib/screens/seller/seller_hub_screen.dart#L248)
  - [Ruta registrada en AppRouter](../../resell_o/lib/routes/app_router.dart#L181)

## 10) Mapeo de estados para app (detalle importante)

- En endpoint de orders, estado `paid` ahora se traduce a `Pagado`:
  - [_ESTADO_ES](../app/api/v1/endpoints/orders.py#L101)
  - [paid -> Pagado](../app/api/v1/endpoints/orders.py#L104)
- Conversor de pedido a orden:
  - [_pedido_a_orden](../app/api/v1/endpoints/orders.py#L145)

## 11) Guion recomendado para explicarlo en demo

1. Usuario toca "Pagar" en checkout.
2. Flutter crea pedido local y luego llama create-order PayPal.
3. Interceptor adjunta JWT automaticamente.
4. Backend crea transaccion local + orden PayPal externa.
5. Flutter abre navegador PayPal.
6. Usuario aprueba.
7. App vuelve por deep link y captura pago.
8. Backend completa transaccion, crea escrows y marca pedido pagado.
9. Al confirmar entrega por QR, backend libera escrow y envia payout al vendedor.
10. Si vendedor no tiene email PayPal, la transferencia queda `Pendiente_email`.

## 12) Nota de configuracion PayPal

- Variables de settings PayPal:
  - [paypal_client_id](../app/config/settings.py#L175)
  - [paypal_secret](../app/config/settings.py#L176)
  - [paypal_base_url](../app/config/settings.py#L180)
- Para payout real en tu cuenta/app PayPal, la capability de Payouts debe estar habilitada en PayPal Developer.
