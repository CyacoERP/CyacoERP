# Trazabilidad Funcional del Gantt

Este documento mapea cada bloque del Gantt con su evidencia actual en código.

## WBS 1. Preparacion y Base Tecnica

| Tarea | Estado | Evidencia |
|---|---|---|
| 1.1 Planeacion y kickoff | Hecho | [gantt fuente](docs/gantt.txt) |
| 1.2 Repositorio/config base | Hecho | [compose base](docker-compose.yml), [backend package](backend/package.json), [frontend package](frontend/package.json) |
| 1.3 Docker + herramientas locales | Hecho | [compose postgres/pgadmin](docker-compose.yml), [backend env](backend/.env), [backend env prod](backend/.env.prod) |
| 1.4 Politica ramas y PR | Pendiente | [gantt fuente](docs/gantt.txt) |

## WBS 2. Clientes y Catalogo

| Tarea | Estado | Evidencia |
|---|---|---|
| 2.1 CRUD clientes backend | Hecho | [clientes controller](backend/src/clientes/clientes.controller.ts), [clientes service](backend/src/clientes/clientes.service.ts), [crear cliente dto](backend/src/clientes/dto/crear-cliente.dto.ts) |
| 2.2 CRUD clientes frontend | Hecho | [gestionar clientes componente](frontend/src/app/modules/admin/components/gestionar-clientes/gestionar-clientes.componente.ts), [cliente servicio](frontend/src/app/modules/admin/services/cliente.servicio.ts), [rutas app](frontend/src/app/app.routes.ts) |
| 2.3 CRUD catalogo backend | Hecho | [productos controller](backend/src/productos/productos.controller.ts), [categorias controller](backend/src/productos/categorias.controller.ts), [schema catalogo](backend/prisma/schema.prisma) |
| 2.4 CRUD catalogo frontend | Hecho | [catalogo componente](frontend/src/app/modules/catalogo/components/catalogo/catalogo.componente.ts), [gestionar productos componente](frontend/src/app/modules/admin/components/gestionar-productos/gestionar-productos.componente.ts), [producto servicio](frontend/src/app/modules/catalogo/services/producto.servicio.ts) |
| 2.5 Compatibilidad base productos | Parcial | [schema relaciones](backend/prisma/schema.prisma), [producto modelo shared](frontend/src/app/shared/models/producto.modelo.ts) |
| 2.6 Subida y vista PDF | Hecho | [productos controller](backend/src/productos/productos.controller.ts), [productos service](backend/src/productos/productos.service.ts), [producto card](frontend/src/app/modules/catalogo/components/producto-card/producto-card.componente.ts) |
| 2.7 Tests catalogo/clientes | Hecho | [cliente servicio spec](frontend/src/app/modules/admin/services/cliente.servicio.spec.ts), [producto servicio spec](frontend/src/app/modules/catalogo/services/producto.servicio.spec.ts), [carrito servicio spec](frontend/src/app/modules/catalogo/services/carrito.servicio.spec.ts) |

## WBS 3. Cotizacion y Ventas

| Tarea | Estado | Evidencia |
|---|---|---|
| 3.1 Carrito cotizacion frontend | Parcial | [carrito servicio](frontend/src/app/modules/catalogo/services/carrito.servicio.ts), [solicitar cotizacion](frontend/src/app/modules/cotizaciones/components/solicitar-cotizacion/solicitar-cotizacion.componente.ts) |
| 3.2 Logica carrito/reglas backend | Hecho | [cotizaciones service](backend/src/cotizaciones/cotizaciones.service.ts), [crear cotizacion dto](backend/src/cotizaciones/dto/crear-cotizacion.dto.ts) |
| 3.3 PDF cotizacion | Hecho | [detalle cotizacion componente](frontend/src/app/modules/cotizaciones/components/detalle-cotizacion/detalle-cotizacion.componente.ts) |
| 3.4 Estados/versionado cotizacion | Hecho | [schema estado cotizacion](backend/prisma/schema.prisma), [actualizar estado dto](backend/src/cotizaciones/dto/actualizar-estado-cotizacion.dto.ts) |
| 3.5 Descuentos y margen | Hecho | [cotizaciones service](backend/src/cotizaciones/cotizaciones.service.ts) |
| 3.6 Tests ventas | Hecho | [cotizaciones service spec](backend/src/cotizaciones/cotizaciones.service.spec.ts) |

## WBS 4. Proyectos Core

| Tarea | Estado | Evidencia |
|---|---|---|
| 4.1 CRUD proyectos backend | Hecho | [proyectos controller](backend/src/proyectos/proyectos.controller.ts), [proyectos service](backend/src/proyectos/proyectos.service.ts), [crear proyecto dto](backend/src/proyectos/dto/crear-proyecto.dto.ts) |
| 4.2 CRUD proyectos frontend | Hecho | [proyecto servicio](frontend/src/app/modules/proyectos/services/proyecto.servicio.ts), [lista proyectos componente](frontend/src/app/modules/proyectos/components/lista-proyectos/lista-proyectos.componente.ts), [detalle proyecto componente](frontend/src/app/modules/proyectos/components/detalle-proyecto/detalle-proyecto.componente.ts) |
| 4.3 Kanban tareas y avance | Hecho | [crear tarea dto](backend/src/proyectos/dto/crear-tarea-proyecto.dto.ts), [actualizar tarea dto](backend/src/proyectos/dto/actualizar-tarea-proyecto.dto.ts), [proyectos service](backend/src/proyectos/proyectos.service.ts) |
| 4.4 Portal cliente lectura | Hecho | [proyectos controller](backend/src/proyectos/proyectos.controller.ts), [auth guard frontend](frontend/src/app/core/guards/auth.guard.ts), [detalle proyecto componente](frontend/src/app/modules/proyectos/components/detalle-proyecto/detalle-proyecto.componente.ts) |
| 4.5 Tests proyectos | Hecho | [proyectos service spec](backend/src/proyectos/proyectos.service.spec.ts), [proyecto servicio spec](frontend/src/app/modules/proyectos/services/proyecto.servicio.spec.ts) |

## WBS 5. Dashboards y Reportes

| Tarea | Estado | Evidencia |
|---|---|---|
| 5.1 Dashboard ventas/proyectos | Hecho | [dashboard ventas componente](frontend/src/app/modules/dashboards/components/dashboard-ventas/dashboard-ventas.componente.ts), [dashboard proyectos componente](frontend/src/app/modules/dashboards/components/dashboard-proyectos/dashboard-proyectos.componente.ts), [reportes controller](backend/src/reportes/reportes.controller.ts) |
| 5.2 Dashboard catalogos/consultas | Hecho | [dashboard clientes componente](frontend/src/app/modules/dashboards/components/dashboard-clientes/dashboard-clientes.componente.ts), [reportes controller](backend/src/reportes/reportes.controller.ts) |
| 5.3 Exportar PDF/Excel | Hecho | [reportes controller](backend/src/reportes/reportes.controller.ts), [reportes service](backend/src/reportes/reportes.service.ts) |
| 5.4 Tests dashboards | Hecho | [reportes service spec](backend/src/reportes/reportes.service.spec.ts) |

## WBS 6. Presentacion y Pruebas Finales

| Tarea | Estado | Evidencia |
|---|---|---|
| 6.1 E2E flujo completo | Hecho | [backend e2e](backend/test/app.e2e-spec.ts) |
| 6.2 Presentacion interna | Pendiente | [gantt fuente](docs/gantt.txt) |
| 6.3 Ajustes preproduccion | Hecho | [backend env prod](backend/.env.prod), [backend dockerfile](backend/Dockerfile) |
| 6.4 Despliegue y cierre | Hecho | [docker compose prod](docker-compose.prod.yml), [nginx config](nginx.conf) |

## Nota de avance

Con esta iteracion quedaron cerrados los bloques funcionales del proyecto dentro de codigo: clientes frontend, catalogo frontend con gestion administrativa, descarga imprimible de cotizaciones, exportacion PDF/Excel de reportes, pruebas unitarias y e2e, y configuracion base para despliegue. Los pendientes restantes del Gantt son organizacionales: politica de ramas/PR y presentacion interna.
